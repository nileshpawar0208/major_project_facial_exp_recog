import os
import cv2
import numpy as np
from flask import Flask, render_template, Response, request, jsonify, send_from_directory
from keras.models import load_model
import datetime

app = Flask(__name__)

# Load model and face detector
model = load_model('emotion_model.h5', compile=False)
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

# Emotion labels
emotion_dict = {
    0: "Angry",
    1: "Disgust",
    2: "Fear",
    3: "Happy",
    4: "Sad",
    5: "Surprise",
    6: "Neutral"
}

# Initialize webcam
video = cv2.VideoCapture(0)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    def generate():
        while True:
            success, frame = video.read()
            if not success:
                break
            _, buffer = cv2.imencode('.jpg', frame)
            frame_bytes = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
    return Response(generate(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/saved_images/<filename>')
def get_image(filename):
    return send_from_directory('saved_images', filename)

@app.route('/capture', methods=['POST'])
def capture():
    success, frame = video.read()
    if not success:
        return jsonify({'error': 'Failed to capture image'})

    # Save the image
    timestamp = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
    filename = f"{timestamp}.jpg"
    save_path = os.path.join('saved_images', filename)
    cv2.imwrite(save_path, frame)

    # Convert to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)

    emotion = "Unknown"
    for (x, y, w, h) in faces:
        roi = gray[y:y+h, x:x+w]
        roi = cv2.resize(roi, (48, 48))
        roi = roi.astype('float32') / 255.0
        roi = np.expand_dims(roi, axis=0)
        roi = np.expand_dims(roi, axis=-1)

        prediction = model.predict(roi)
        emotion = emotion_dict[np.argmax(prediction)]

    return jsonify({
        'emotion': emotion,
        'image_path': f"/saved_images/{filename}"
    })

if __name__ == '__main__':
    if not os.path.exists('saved_images'):
        os.makedirs('saved_images')
    app.run(debug=True)
