const video = document.getElementById('video');
const canvas = document.getElementById('canvas');
const captureButton = document.getElementById('capture');
const resultDiv = document.getElementById('result');

// Get camera stream
navigator.mediaDevices.getUserMedia({ video: true })
  .then(stream => {
    video.srcObject = stream;
  });

// Handle capture
captureButton.addEventListener('click', () => {
  canvas.getContext('2d').drawImage(video, 0, 0, canvas.width = video.videoWidth, canvas.height = video.videoHeight);
  const imageData = canvas.toDataURL('image/png');

  fetch('/predict', {
    method: 'POST',
    body: JSON.stringify({ image: imageData }),
    headers: { 'Content-Type': 'application/json' }
  })
  .then(response => response.json())
  .then(data => {
    resultDiv.innerHTML = `
      <h3>Detected Emotion: ${data.emotion}</h3>
      <img src="${data.emoji}" width="100" />
    `;
  });
});

